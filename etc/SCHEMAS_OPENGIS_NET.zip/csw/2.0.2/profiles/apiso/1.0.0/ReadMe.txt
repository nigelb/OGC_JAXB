OpenGIS(r) CSW 2.0.2 ISO Metadata Application Profile ReadMe.txt

2007-07-19  Uwe Voges

  * csw/2.0.2/profiles/apiso/1.0.0: See OGC 07-045 for associated specification
  * apiso/1.0.0: validated using oXygen XML Editor 8.2 build 2007062515 (Xerces-J 2.9.0) - kstegemoller
  * apiso/1.0.0: validated using XMLSpy 2007 sp1 - Uwe Voges
  * iso/19139/20060504: added ISO-19139 used by apiso/1.0.0
  * APISO 1.0.0 builds upon the following schemas
    + OGC csw/2.0.2
    + OGC xlink/1.0.0
    + ISO iso/19139/20060504
    + OGC ows/1.0.0
    + OGC filter/1.1.0
    + OGC gml/3.1.1/base

The Open Geospatial Consortium, Inc. official schema repository is at
  http://schemas.opengis.net/ .
Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/policies/ .
Additional rights of use are described at
  http://www.opengeospatial.org/legal/ . 

Copyright (c) 2007 Open Geospatial Consortium, Inc. All Rights Reserved.
