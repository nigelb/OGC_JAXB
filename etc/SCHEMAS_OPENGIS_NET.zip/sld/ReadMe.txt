The sets of XML Schema Documents for Styled Layer Descriptor Versions 
0.7.2 through 1.0.20 have been edited to reflect the corrigendum to 
document OGC 02-070 that is based on the change requests: 
OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
OGC 05-081r2 "Change to use relative paths"

Arliss Whiteside, 2005-11-22

