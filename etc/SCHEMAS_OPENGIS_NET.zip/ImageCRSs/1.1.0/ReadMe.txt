This set of XML Documents for image CRS definitions have been edited 
to reflect the corrigendum to document OGC 05-027r1 that is based on 
the change requests: 
OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
OGC 05-081r2 "Change to use relative paths"

Arliss Whiteside, 2005-11-22

