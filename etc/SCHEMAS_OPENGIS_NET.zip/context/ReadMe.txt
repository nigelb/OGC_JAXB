2007-04-12  Kevin Stegemoller
  * context/1.1.0/collection.xml: fixed schemaLocation caught in OWS-4
    CITE tests
  * context/1.1.0/context.xml: fixed schemaLocation caught in OWS-4
    CITE tests

2005-11-22  Arliss Whiteside

  * v1.1.0, v1.0.0: The XML Schema Documents for OpenGIS(r) Context
    Versions have been edited to reflect the corrigenda to documents
    1.0.0 (OGC 03-036r2) and 1.1.0 (OGC 05-005) which are based on the
    change requests: 
    OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
    OGC 05-081r2 "Change to use relative paths"

