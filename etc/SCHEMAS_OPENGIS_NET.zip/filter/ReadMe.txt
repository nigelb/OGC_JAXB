The sets of XML Schema Documents for OpenGIS� Filter Encoding Versions 
1.0.0, 1.0.20, and 1.1.0 have been edited to reflect the corrigenda to 
documents OGC 02-059 and OGC 04-095 that are based on the change requests: 
OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
OGC 05-081r2 "Change to use relative paths"

Arliss Whiteside, 2005-11-22

