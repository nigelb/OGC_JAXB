OpenGIS(r) Observation Extensions - ReadMe.txt

The Observations and Measurements schema are defined in the OGC document
07-022r1.  The Observation Extensions are amended in the OGC change request
document 08-022r1.

More information on the OGC O&M standard may be found at
 http://www.opengeospatial.org/standards/om

2008-02-18  Simon Cox

  * The Observation Extensions schemas were moved here from the previous
	 location http://schemas.opengis.net/om/1.0.0/extensions and also moved into
    a separate namespace http://www.opengis.net/omx/1.0

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2007-2008 Open Geospatial Consortium, Inc. All Rights Reserved.

-----------------------------------------------------------------------
